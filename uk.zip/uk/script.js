$(document).ready(function () {
  // Mobile Menu Toggle
  $("#mobileMenuButton").click(function () {
    $("#mobileMenu").slideToggle();
  });

  // Destination Slider
  const sliderContainer = $("#sliderContainer");
  const sliderItems = $(".slider-item");
  const sliderDots = $("#sliderDots");
  const itemCount = sliderItems.length;
  let currentIndex = 0;

  // Create dots
  for (let i = 0; i < itemCount; i++) {
    sliderDots.append('<div class="dot" data-index="' + i + '"></div>');
  }

  const dots = $(".dot");
  dots.first().addClass("active");

  // Update slider position
  function updateSlider() {
    let itemWidth = sliderItems.first().outerWidth(true);
    let translateX = -currentIndex * itemWidth;
    sliderContainer.css("transform", "translateX(" + translateX + "px)");

    // Update active dot
    dots.removeClass("active");
    dots.eq(currentIndex).addClass("active");
  }

  // Next button
  $("#nextBtn").click(function () {
    if (currentIndex < itemCount - 1) {
      currentIndex++;
    } else {
      currentIndex = 0;
    }
    updateSlider();
  });

  // Previous button
  $("#prevBtn").click(function () {
    if (currentIndex > 0) {
      currentIndex--;
    } else {
      currentIndex = itemCount - 1;
    }
    updateSlider();
  });

  // Dot navigation
  dots.click(function () {
    currentIndex = $(this).data("index");
    updateSlider();
  });

  // Auto-slide (optional)
  let autoSlide = setInterval(function () {
    $("#nextBtn").click();
  }, 5000);

  // Pause on hover
  $(".destination-slider").hover(
    function () {
      clearInterval(autoSlide);
    },
    function () {
      autoSlide = setInterval(function () {
        $("#nextBtn").click();
      }, 5000);
    }
  );

  // Responsive adjustments
  function handleResize() {
    // Reset slider position on resize
    updateSlider();
  }

  // Debounce resize events
  let resizeTimer;
  $(window).resize(function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(handleResize, 250);
  });
});

const menuToggle = document.getElementById("menu-toggle");
const mobileMenu = document.getElementById("mobile-menu");

menuToggle.addEventListener("click", () => {
  mobileMenu.classList.toggle("hidden");
});

document.addEventListener("DOMContentLoaded", function () {
  // Get all filter buttons and gallery items
  const filterButtons = document.querySelectorAll(".filter-btn");
  const galleryItems = document.querySelectorAll(".gallery-item");

  // Add click event listeners to each filter button
  filterButtons.forEach((button) => {
    button.addEventListener("click", function () {
      // Remove active class from all buttons
      filterButtons.forEach((btn) => {
        btn.classList.remove("bg-indigo-600", "text-white");
        btn.classList.add("bg-gray-200", "text-gray-800");
      });

      // Add active class to clicked button
      this.classList.remove("bg-gray-200", "text-gray-800");
      this.classList.add("bg-indigo-600", "text-white");

      const filterValue = this.getAttribute("data-filter");

      // Filter gallery items
      galleryItems.forEach((item) => {
        if (filterValue === "all") {
          item.style.display = "block";
        } else {
          if (item.getAttribute("data-category") === filterValue) {
            item.style.display = "block";
          } else {
            item.style.display = "none";
          }
        }
      });
    });
  });
});
